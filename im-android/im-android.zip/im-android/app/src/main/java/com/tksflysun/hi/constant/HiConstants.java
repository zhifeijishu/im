package com.tksflysun.hi.constant;

public interface HiConstants {
    static final String TOKEN="com.tksflysun.hi_token";
}
