package com.tksflysun.hi.bean.res;

public interface ResCode {
    static final String SUCCESS="000001";
    static final String ERROR="000002";

}
