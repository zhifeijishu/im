package com.tksflysun.hi.common;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.tksflysun.hi.constant.HiConstants;

/**
 * @author  lpf
 * 全局共享
 */
public class HiApplication extends Application {
    private static HiApplication instance;
    public static HiApplication getInstance() {
        return instance;
    }
    @Override
    public void onCreate() {
        super.onCreate();
        instance=this;
    }
    public void cache(String key ,String value){
        String valueEncrypt = AESUtil.encrypt(value);
        Log.i("加密之前的value", value);
        Log.i("加密之后的value", valueEncrypt);
        Log.i("解密之后的value", AESUtil.decrypt(valueEncrypt));
        SharedPreferences sharedPreferences = getSharedPreferences("data", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(HiConstants.TOKEN, valueEncrypt);
        editor.commit();
    }
    public String getCache(String key){
        SharedPreferences sharedPreferences = getSharedPreferences("data", Context.MODE_PRIVATE);
         String valueEncrypt=sharedPreferences.getString(key,"");
         return AESUtil.decrypt(valueEncrypt);
    }
}
