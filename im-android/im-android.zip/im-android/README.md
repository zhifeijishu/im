# LoginUI-Android
Login User Interface in android with innovative, beautiful and creative background 😊😊😉

## 📸 Screenshots

**Please click the image below to enlarge.**

<img src="https://github.com/Shashank02051997/LoginUI-Android/blob/master/Screenshots/Screenshot_20181211-033917.png" height="600" width="300" hspace="40"><img src="https://github.com/Shashank02051997/LoginUI-Android/blob/master/Screenshots/Screenshot_20181211-033921.png" height="600" width="300" hspace="40">

<img src="https://github.com/Shashank02051997/LoginUI-Android/blob/master/Screenshots/Screenshot_20181211-033951.png" height="600" width="300" hspace="40"><img src="https://github.com/Shashank02051997/LoginUI-Android/blob/master/Screenshots/Screenshot_20181211-033955.png" height="600" width="300" hspace="40">

## Contributing

Please fork this repository and contribute back using
[pull requests](https://github.com/Shashank02051997/LoginUI-Android/pulls).

Any contributions, large or small, major features, bug fixes, are welcomed and appreciated
but will be thoroughly reviewed .

### Contact - Let's become friend
- [Twitter](https://twitter.com/shashank020597)
- [Github](https://github.com/Shashank02051997)
- [Linkedin](https://www.linkedin.com/in/shashank-singhal-a87729b5/)
- [Facebook](https://www.facebook.com/shashanksinghal02)

### Like our facebook page
- [Android UI's Bucket](https://www.facebook.com/androiduisbucket)

## Donation
If this project help you reduce time to develop, you can give me a cup of coffee :) 

<a href="https://www.buymeacoffee.com/mXUuDW7" target="_blank"><img src="https://bmc-cdn.nyc3.digitaloceanspaces.com/BMC-button-images/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: auto !important;width: auto !important;" ></a>

### Show some :heart: and star the repo to support the project
